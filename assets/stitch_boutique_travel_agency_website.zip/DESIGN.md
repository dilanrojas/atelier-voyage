---
name: Atelier Voyage
colors:
  surface: '#fbf9f6'
  surface-dim: '#dbdad7'
  surface-bright: '#fbf9f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f0'
  surface-container: '#efeeeb'
  surface-container-high: '#eae8e5'
  surface-container-highest: '#e4e2df'
  on-surface: '#1b1c1a'
  on-surface-variant: '#584239'
  inverse-surface: '#30312f'
  inverse-on-surface: '#f2f0ed'
  outline: '#8c7167'
  outline-variant: '#e0c0b4'
  surface-tint: '#a63b00'
  primary: '#a23900'
  on-primary: '#ffffff'
  primary-container: '#c74d10'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb599'
  secondary: '#625e59'
  on-secondary: '#ffffff'
  secondary-container: '#e5ded8'
  on-secondary-container: '#66625d'
  tertiary: '#75553d'
  on-tertiary: '#ffffff'
  tertiary-container: '#906d54'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbce'
  primary-fixed-dim: '#ffb599'
  on-primary-fixed: '#370e00'
  on-primary-fixed-variant: '#7f2b00'
  secondary-fixed: '#e8e1db'
  secondary-fixed-dim: '#ccc5bf'
  on-secondary-fixed: '#1e1b17'
  on-secondary-fixed-variant: '#4a4642'
  tertiary-fixed: '#ffdcc4'
  tertiary-fixed-dim: '#e8bea1'
  on-tertiary-fixed: '#2c1604'
  on-tertiary-fixed-variant: '#5e402a'
  background: '#fbf9f6'
  on-background: '#1b1c1a'
  surface-variant: '#e4e2df'
typography:
  display-hero:
    fontFamily: Playfair Display
    fontSize: 68px
    fontWeight: '400'
    lineHeight: 76px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '400'
    lineHeight: 48px
    letterSpacing: -0.01em
  headline-xl:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '400'
    lineHeight: 56px
    letterSpacing: -0.015em
  headline-xl-mobile:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 40px
    letterSpacing: 0em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 36px
    fontWeight: '500'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Playfair Display
    fontSize: 26px
    fontWeight: '500'
    lineHeight: 34px
    letterSpacing: 0em
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: 0.01em
  editorial-italic:
    fontFamily: Playfair Display
    fontSize: 22px
    fontWeight: '400'
    lineHeight: 32px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 30px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0.005em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-caps:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.14em
  caption:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  space-3xl: 4.5rem
  space-4xl: 6rem
  space-5xl: 9rem
  gutter-desktop: 2rem
  gutter-mobile: 1rem
  margin-desktop: 4rem
  margin-mobile: 1.5rem
  container-max: 1440px
---

## Brand & Style

This design system embodies the rare convergence of bespoke curation, untamed global discovery, and refined editorial luxury. Crafted for discerning travelers seeking unmapped experiences, private sanctuaries, and transformative journeys, the interface evokes the tactile stillness of a collector’s art monograph combined with the precision of high-touch concierge service.

The design movement balances **Modern Editorial Luxury** with **Organic Tactility**:
- **Atmosphere:** Sun-drenched, contemplative, and architectural. Generous negative space acts as a deliberate design element, giving imagery and typography room to breathe.
- **Tone:** Cultivated, discreet, authoritative, and evocative.
- **Visual Distinction:** Completely decoupled from transactional travel booking engines or sterile SaaS conventions. The system leans into warm, mineral-tinted paper grounds, hairline borders evocative of fine stationery, and asymmetric, high-fashion editorial pacing.

## Colors

The palette draws directly from geological strata, aged heavy-stock vellum, and the incandescent glow of dusk across wild landscapes.

### Palette Architecture
- **Canvas & Surface Base:** Warm Alabaster (`#FAF8F5`) serves as the foundational light floor, supported by Sand Linen (`#F4EFEB`) for inset surfaces, dynamic editorial cards, and structural panels.
- **Deep Pigments (Typography & Hierarchy):** Deep Espresso (`#1C1A17`) handles primary headings and high-contrast titles, while Burnished Charcoal (`#2D2A26`) and Muted Bark (`#686259`) ensure accessible, legible body copy without harsh digital black.
- **Primary Action (Sunset Ochre):** Terracotta Ember (`#D95A1E`) delivers a vibrant, sun-baked burnt orange accent reserved exclusively for pivotal conversion moments, curated tags, and deliberate focal points.
- **Borders & Micro-Accents:** Raw Sand (`#E5DDD0`) provides delicate, whisper-thin structural definition, avoiding synthetic grey tones entirely.

## Typography

Typography functions as the voice of the curator. The pairing juxtaposes the timeless, transitional poise of **Playfair Display** with the airy, hyper-clean cadence of **Plus Jakarta Sans**.

### Typographic Rules
- **Editorial Contrast:** Hero headlines should often pair a dramatic serif statement with a brief `label-caps` metadata badge tracking at `+0.14em` above it.
- **Narrative Accents:** Use `editorial-italic` sparingly for destination epigraphs, traveler reflections, or bespoke itinerary notes.
- **Body Rhythm:** Generous line heights (`1.6x` to `1.7x` the font size) prevent visual density, ensuring long-form destination dossiers read like luxury travel essays.

## Layout & Spacing

The layout model adheres to an expansive, high-fashion 12-column asymmetric grid designed to evoke broadsheet journals and bespoke travel folios.

### Structure & Rhythm
- **Columns:** 12 columns on desktop (1024px+), 8 columns on tablet (768px–1023px), and 4 columns on mobile (<768px).
- **Margins & Gutters:** Desktop experiences utilize wide `4rem` outer gutters to frame content inward. A max-width boundary of `1440px` guarantees structural balance on ultra-wide viewports.
- **Negative Space Calibration:** Vertical rhythm uses the expanded tokens (`space-3xl` through `space-5xl`) between thematic clusters. Sections are separated by breathing room rather than solid divider blocks.
- **Editorial Asymmetry:** Feature listings should intentionally break uniform card grids—alternating full-width panoramic imagery (spanning 8 or 12 columns) with narrative itinerary sidebars (spanning 4 columns).

## Elevation & Depth

To preserve an organic, editorial aura, this design system rejects heavy drop shadows, synthetic neon glows, and plastic elevation tiers.

### Depth Principles
- **Atmospheric Layering:** Depth is communicated through tonal shifts rather than blur-based elevation. A secondary card or modular panel rests at the `Sand Linen` tone (`#F4EFEB`) against the `Warm Alabaster` foundation (`#FAF8F5`).
- **Low-Contrast Micro-Borders:** Precision 1px hairline rules in `#E5DDD0` demarcate surfaces, itinerary days, and navigation bars with the delicacy of bookbinding.
- **Sunlit Ambient Shading (Float Only):** For floating navigational pills, private inquiry modals, and dropdown overlays, utilize an ultra-diffused, warm-tinted ambient shadow:
  - `0 12px 36px -4px rgba(28, 26, 23, 0.06), 0 4px 12px -2px rgba(28, 26, 23, 0.03)`
- **Image Depth:** Photography remains crisp, edge-to-edge or enclosed in hairline frames, allowing natural depth of field in imagery to anchor the spatial plane.

## Shapes

The shape architecture is restrained, disciplined, and bespoke. Elements employ subtle soft-corner micro-radii (`0.25rem` / 4px base), retaining the crisp edges of fine stationery and architectural prints while removing visual harshness.

### Usage
- **Cards, Modals & Insets:** Micro-softness (`0.25rem` to `0.375rem`) ensures an architectural finish.
- **Interactive Badges & Filters:** Subtle architectural containment rather than heavy circular geometries.
- **Full Bleed Editorial Frames:** Destination hero imagery should utilize flush square edges (`0px`) when intersecting viewport boundaries to emphasize raw scale.

## Components

### Buttons
- **Primary CTA (The Sunset Ochre):** Background `#D95A1E`, foreground `#FAF8F5`. Uses `label-caps` typography with increased letter spacing. Padding: `14px 28px`. Border-radius: `4px`. Hover initiates a warm, deeper shade transition (`#C24D17`) accompanied by a subtle 2px rightward translate on trailing arrows.
- **Editorial Secondary:** Background transparent, border: `1px solid #2D2A26`, text: `#2D2A26`. Hover: fills `#2D2A26` with text shifting to `#FAF8F5`.
- **Text / Curatorial Link:** Minimal inline link in `#1C1A17` underlined by a delicate `1px` rule offset by `4px` with a transition to `#D95A1E`.

### Cards (Expedition & Sanctuary Dossiers)
- Built on `#F4EFEB` or `#FAF8F5` with a subtle `1px solid #E5DDD0` perimeter.
- Image aspect ratios prioritize cinematic crops (`16:10` or `3:2`) with soft progressive contrast overlays at the base for legibility.
- Content arrangement: Overline country tag in `label-caps` (`#D95A1E`), followed by destination name in `headline-md`, followed by curated metadata (e.g., "6 Guests • 8 Days • Exclusive Access") separated by mid-dots in `body-sm`.

### Input Fields & Bespoke Inquiry Forms
- Background `#FAF8F5`, enclosed by `1px solid #E5DDD0`.
- Font: `body-md` in `#1C1A17`. Placeholder text in `#A39C93`.
- Focus state: Border transitions smoothly to `#2D2A26` without blue or neon rings; focus shadow is a subtle 1px inner keyline.
- Floating label or crisp uppercase top labels using `label-caps` in `#686259`.

### Chips & Filter Tags
- Inactive: Background transparent, border: `1px solid #E5DDD0`, text: `#686259`, `label-caps` sizing.
- Active: Background `#2D2A26`, border: `1px solid #2D2A26`, text: `#FAF8F5`.

### Checkboxes & Radio Buttons
- Custom square/circle with `1.25rem` diameter, bordered by `1.5px solid #686259`.
- Checked state: `#D95A1E` fill with an interior minimalist off-white checkmark or solid center pip.

### Lists & Itinerary Steppers
- Timeline markers: Clean, hollow 8px circular nodes in `#D95A1E` connected by a continuous vertical hairline rule in `#E5DDD0`.
- Day markers: Displayed via `headline-sm` with time/distance metrics aligned right in `label-caps`.

### Bespoke Additions
- **Editorial Pull-Quotes:** Styled using `editorial-italic` framed by an asymmetrical left-side hairline bar in `#D95A1E` with generous indenting (`space-xl`).
- **Curator Signature Badges:** Miniature circular portrait tokens (40px) accompanied by a handwritten cursive or small caps endorsement string for private guide introductions.